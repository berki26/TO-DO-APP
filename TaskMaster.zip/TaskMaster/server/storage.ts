import { todos, users, type User, type InsertUser, type Todo, type InsertTodo, type UpdateTodo } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Todo CRUD operations
  getAllTodos(): Promise<Todo[]>;
  getTodoById(id: number): Promise<Todo | undefined>;
  createTodo(todo: InsertTodo): Promise<Todo>;
  updateTodo(id: number, todo: UpdateTodo): Promise<Todo | undefined>;
  deleteTodo(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private todosMap: Map<number, Todo>;
  currentUserId: number;
  currentTodoId: number;

  constructor() {
    this.users = new Map();
    this.todosMap = new Map();
    this.currentUserId = 1;
    this.currentTodoId = 1;
    
    // Add some initial todos for testing
    this.createTodo({
      title: "Complete project proposal",
      completed: false,
      category: "Work",
      priority: "High"
    });
    
    this.createTodo({
      title: "Buy groceries",
      completed: true,
      category: "Personal",
      priority: "Medium"
    });
    
    this.createTodo({
      title: "Schedule dentist appointment",
      completed: false,
      category: "Health",
      priority: "Low"
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Todo CRUD operations
  async getAllTodos(): Promise<Todo[]> {
    return Array.from(this.todosMap.values());
  }
  
  async getTodoById(id: number): Promise<Todo | undefined> {
    return this.todosMap.get(id);
  }
  
  async createTodo(insertTodo: InsertTodo): Promise<Todo> {
    const id = this.currentTodoId++;
    const todo: Todo = { ...insertTodo, id };
    this.todosMap.set(id, todo);
    return todo;
  }
  
  async updateTodo(id: number, updateTodo: UpdateTodo): Promise<Todo | undefined> {
    const existingTodo = this.todosMap.get(id);
    
    if (!existingTodo) {
      return undefined;
    }
    
    const updatedTodo: Todo = { ...existingTodo, ...updateTodo };
    this.todosMap.set(id, updatedTodo);
    
    return updatedTodo;
  }
  
  async deleteTodo(id: number): Promise<boolean> {
    return this.todosMap.delete(id);
  }
}

export const storage = new MemStorage();
