import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Define Todo table schema
export const todos = pgTable("todos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  completed: boolean("completed").notNull().default(false),
  category: text("category"),
  priority: text("priority"),
});

// Create insert schema for Todo
export const insertTodoSchema = createInsertSchema(todos).pick({
  title: true,
  completed: true,
  category: true,
  priority: true,
});

// Create update schema for Todo
export const updateTodoSchema = createInsertSchema(todos).pick({
  title: true,
  completed: true,
  category: true,
  priority: true,
});

// Define types
export type InsertTodo = z.infer<typeof insertTodoSchema>;
export type UpdateTodo = z.infer<typeof updateTodoSchema>;
export type Todo = typeof todos.$inferSelect;
