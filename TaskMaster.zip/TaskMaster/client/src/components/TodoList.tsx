import { Todo } from "@shared/schema";
import TodoItem from "./TodoItem";
import { Card, CardContent } from "@/components/ui/card";
import { ClipboardList, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TodoListProps {
  todos: Todo[];
  isLoading: boolean;
  onEdit: (todo: Todo) => void;
}

export default function TodoList({ todos, isLoading, onEdit }: TodoListProps) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="p-4">
            <div className="flex items-start space-x-3">
              <Skeleton className="h-5 w-5 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-5 w-3/4" />
                <div className="flex space-x-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    );
  }
  
  if (todos.length === 0) {
    return (
      <Card className="p-8 text-center">
        <CardContent className="pt-6">
          <ClipboardList className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 text-lg">No tasks found.</p>
          <p className="text-gray-400 mt-1">Add a new task or adjust your filters.</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-3">
      {todos.map((todo) => (
        <TodoItem key={todo.id} todo={todo} onEdit={onEdit} />
      ))}
    </div>
  );
}
