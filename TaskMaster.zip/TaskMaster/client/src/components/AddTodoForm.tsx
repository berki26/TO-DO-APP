import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { ChevronDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertTodoSchema } from "@shared/schema";

// Available categories and priorities
const categories = ['Work', 'Personal', 'Health', 'Shopping', 'Education'];
const priorities = ['High', 'Medium', 'Low'];

export default function AddTodoForm() {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('');
  const { toast } = useToast();
  
  const { mutate: addTodo, isPending } = useMutation({
    mutationFn: async () => {
      // Validate data with the insert schema
      const todoData = insertTodoSchema.parse({
        title,
        completed: false,
        category: category || null,
        priority: priority || null
      });
      
      const res = await apiRequest('POST', '/api/todos', todoData);
      return res.json();
    },
    onSuccess: () => {
      // Reset form
      setTitle('');
      setCategory('');
      setPriority('');
      
      // Invalidate queries to refresh todo list
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      
      toast({
        title: "Task created",
        description: "Your new task has been added."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to create task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "Task title cannot be empty",
        variant: "destructive"
      });
      return;
    }
    
    addTodo();
  };
  
  return (
    <Card className="mb-8">
      <CardContent className="pt-4">
        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Add a new task..."
            className="flex-grow"
            required
            disabled={isPending}
          />
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="outline" 
                className="flex-shrink-0"
                disabled={isPending}
              >
                {category || 'Category'} <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {categories.map((cat) => (
                <DropdownMenuItem 
                  key={cat} 
                  onClick={() => setCategory(cat)}
                >
                  {cat}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="outline" 
                className="flex-shrink-0"
                disabled={isPending}
              >
                {priority || 'Priority'} <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {priorities.map((pri) => (
                <DropdownMenuItem 
                  key={pri} 
                  onClick={() => setPriority(pri)}
                >
                  {pri}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            type="submit" 
            className="bg-primary hover:bg-primary/90"
            disabled={isPending}
          >
            Add
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
