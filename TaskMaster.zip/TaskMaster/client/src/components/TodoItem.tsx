import { useMutation } from "@tanstack/react-query";
import { Todo } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Pencil, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface TodoItemProps {
  todo: Todo;
  onEdit: (todo: Todo) => void;
}

export default function TodoItem({ todo, onEdit }: TodoItemProps) {
  const { toast } = useToast();
  
  // Toggle completed status
  const { mutate: toggleComplete } = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('PUT', `/api/todos/${todo.id}`, {
        ...todo,
        completed: !todo.completed
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  // Delete todo
  const { mutate: deleteTodo } = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/todos/${todo.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      toast({
        title: "Task deleted",
        description: "The task has been removed."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  // Get border color based on priority and completion status
  const getBorderColorClass = () => {
    if (todo.completed) return 'border-l-green-500';
    
    switch (todo.priority) {
      case 'High': return 'border-l-red-500';
      case 'Medium': return 'border-l-yellow-500';
      case 'Low': return 'border-l-blue-500';
      default: return 'border-l-gray-300';
    }
  };
  
  return (
    <Card className={cn(
      "p-4 hover:shadow-md transition duration-200 border-l-4", 
      getBorderColorClass()
    )}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-grow">
          <Button 
            variant="outline" 
            size="icon" 
            className={cn(
              "w-5 h-5 rounded-full p-0 mt-1",
              todo.completed && "bg-green-500 border-green-500"
            )}
            onClick={() => toggleComplete()}
          >
            {todo.completed && <Check className="h-3 w-3 text-white" />}
          </Button>
          
          <div className="flex-grow">
            <h3 
              className={cn(
                "text-base font-medium leading-tight",
                todo.completed && "line-through text-gray-400"
              )}
            >
              {todo.title}
            </h3>
            
            <div className="flex flex-wrap mt-2 space-x-2">
              {todo.category && (
                <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                  {todo.category}
                </Badge>
              )}
              
              {todo.priority && (
                <Badge 
                  variant="outline" 
                  className={cn(
                    todo.priority === 'High' && "bg-red-100 text-red-800 border-red-200",
                    todo.priority === 'Medium' && "bg-yellow-100 text-yellow-800 border-yellow-200",
                    todo.priority === 'Low' && "bg-green-100 text-green-800 border-green-200"
                  )}
                >
                  {todo.priority}
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit(todo)}
            className="h-8 w-8 text-gray-400 hover:text-gray-600"
          >
            <Pencil className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => deleteTodo()}
            className="h-8 w-8 text-gray-400 hover:text-red-600"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
