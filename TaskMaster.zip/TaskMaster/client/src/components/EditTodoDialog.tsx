import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Todo, updateTodoSchema } from "@shared/schema";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EditTodoDialogProps {
  todo: Todo | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Available categories and priorities
const categories = ['Work', 'Personal', 'Health', 'Shopping', 'Education'];
const priorities = ['High', 'Medium', 'Low'];

export default function EditTodoDialog({ todo, open, onOpenChange }: EditTodoDialogProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string | null>('');
  const [priority, setPriority] = useState<string | null>('');
  const [completed, setCompleted] = useState(false);
  const { toast } = useToast();
  
  // Reset form when todo changes
  useEffect(() => {
    if (todo) {
      setTitle(todo.title);
      setCategory(todo.category);
      setPriority(todo.priority);
      setCompleted(!!todo.completed);
    }
  }, [todo]);
  
  const { mutate: updateTodo, isPending } = useMutation({
    mutationFn: async () => {
      if (!todo) return;
      
      // Validate data with the update schema
      const todoData = updateTodoSchema.parse({
        title,
        completed,
        category,
        priority
      });
      
      const res = await apiRequest('PUT', `/api/todos/${todo.id}`, todoData);
      return res.json();
    },
    onSuccess: () => {
      // Close dialog
      onOpenChange(false);
      
      // Invalidate queries to refresh todo list
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      
      toast({
        title: "Task updated",
        description: "Your task has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "Task title cannot be empty",
        variant: "destructive"
      });
      return;
    }
    
    updateTodo();
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Task</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Task Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                disabled={isPending}
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={category || ''}
                  onValueChange={(value) => setCategory(value || null)}
                  disabled={isPending}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="priority">Priority</Label>
                <Select
                  value={priority || ''}
                  onValueChange={(value) => setPriority(value || null)}
                  disabled={isPending}
                >
                  <SelectTrigger id="priority">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {priorities.map((pri) => (
                      <SelectItem key={pri} value={pri}>
                        {pri}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="completed"
                checked={completed}
                onCheckedChange={(checked) => setCompleted(checked === true)}
                disabled={isPending}
              />
              <Label htmlFor="completed">Mark as completed</Label>
            </div>
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline" disabled={isPending}>
                Cancel
              </Button>
            </DialogClose>
            <Button type="submit" disabled={isPending}>
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
