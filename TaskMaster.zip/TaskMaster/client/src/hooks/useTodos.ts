import { useQuery, useMutation } from "@tanstack/react-query";
import { Todo } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useTodos() {
  const { toast } = useToast();
  
  // Fetch all todos
  const { data: todos = [], isLoading, error } = useQuery<Todo[]>({
    queryKey: ['/api/todos'],
  });
  
  // Toggle todo completion status
  const toggleTodo = useMutation({
    mutationFn: async (todo: Todo) => {
      const res = await apiRequest('PUT', `/api/todos/${todo.id}`, {
        ...todo,
        completed: !todo.completed
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  // Delete a todo
  const deleteTodo = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/todos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      toast({
        title: "Task deleted",
        description: "The task has been removed."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete task",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  });
  
  if (error) {
    toast({
      title: "Error loading tasks",
      description: error instanceof Error ? error.message : "An unknown error occurred",
      variant: "destructive"
    });
  }
  
  return {
    todos,
    isLoading,
    error,
    toggleTodo: toggleTodo.mutate,
    deleteTodo: deleteTodo.mutate
  };
}
