import { useState } from "react";
import { Todo } from "@shared/schema";
import AddTodoForm from "@/components/AddTodoForm";
import FilterBar from "@/components/FilterBar";
import TodoList from "@/components/TodoList";
import EditTodoDialog from "@/components/EditTodoDialog";
import { useTodos } from "@/hooks/useTodos";
import { ClipboardList } from "lucide-react";

export default function Home() {
  const { todos, isLoading } = useTodos();
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [priorityFilter, setPriorityFilter] = useState<string>('');
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  
  // Count incomplete tasks
  const incompleteTasks = todos?.filter(todo => !todo.completed).length || 0;
  
  // Filter todos based on current filters
  const filteredTodos = todos?.filter(todo => {
    // Status filter
    if (filter === 'active' && todo.completed) return false;
    if (filter === 'completed' && !todo.completed) return false;
    
    // Category filter
    if (categoryFilter && todo.category !== categoryFilter) return false;
    
    // Priority filter
    if (priorityFilter && todo.priority !== priorityFilter) return false;
    
    return true;
  }).sort((a, b) => {
    // Sort by completion status first (incomplete first)
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    
    // Then sort by priority
    const priorityOrder: Record<string, number> = { 'High': 1, 'Medium': 2, 'Low': 3 };
    return (priorityOrder[a.priority || ''] || 4) - (priorityOrder[b.priority || ''] || 4);
  }) || [];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <h1 className="text-xl font-semibold text-gray-800 flex items-center">
              <ClipboardList className="h-6 w-6 mr-2 text-primary" />
              Todo List
            </h1>
            <div className="flex items-center">
              <span className="text-sm text-gray-500">{incompleteTasks} remaining</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <AddTodoForm />
        
        <FilterBar 
          filter={filter}
          setFilter={setFilter}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          priorityFilter={priorityFilter}
          setPriorityFilter={setPriorityFilter}
        />
        
        <TodoList 
          todos={filteredTodos} 
          isLoading={isLoading}
          onEdit={setEditingTodo}
        />
        
        <EditTodoDialog 
          todo={editingTodo} 
          open={!!editingTodo} 
          onOpenChange={(open) => {
            if (!open) setEditingTodo(null);
          }} 
        />
      </main>
    </div>
  );
}
